This game uses BattlEye anticheat, you need to disable anticheat in order to use trainer.

For Steam Version:
When launching the game from steam, please select the "Play ARK: No BattlEye AntiCheat, Unofficial Servers Only" option.

For Epic Store Version:
Click ... near the game's icon and select "Play ARK: No BattlEye AntiCheat, Unofficial Servers Only".

=====================================================================================================================================

这款游戏使用BattlEye反作弊，要使用修改器必须运行无BattlEye版本，请按照以下方法运行游戏。

Steam版：运行游戏时选择 "Play ARK: No BattlEye AntiCheat, Unofficial Servers Only" 启动选项。

Epic Store版：点击游戏图标右下角/右方的 ... 打开启动选项，并选择 "Play ARK: No BattlEye AntiCheat, Unofficial Servers Only"