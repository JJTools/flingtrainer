This game uses EAAntiCheat protection, in order to launch this game without EAAntiCheat, please follow these instructions:

1. Delete "EAAntiCheat.GameServiceLauncher.exe" and "EAAntiCheat.GameServiceLauncher.dll" from the game folder (backup these files if necessary).
2. Launch the game. The game will be launched in offline single player mode.

==================================================================================================================

这款游戏使用EAAntiCheat反作弊保护，要使用修改器需禁用EAAntiCheat，请按照以下步骤运行游戏：

1. 删除游戏目录内的"EAAntiCheat.GameServiceLauncher.exe"和"EAAntiCheat.GameServiceLauncher.dll" (如果有需要可以先备份这些文件)
2. 运行游戏（游戏将以离线模式运行）