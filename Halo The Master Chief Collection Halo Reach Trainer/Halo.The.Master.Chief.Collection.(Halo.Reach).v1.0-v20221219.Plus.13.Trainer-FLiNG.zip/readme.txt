This game uses EasyAntiCheat protection, in order to launch this game without EAC, please follow these instructions:

Steam Version:

1. Launch the game from steam, you'll see two options.
2. Select Play Halo: MCC Anti-Cheat Disabled (Mods and Limited Services).

Windows Store Version:

1. Open start menu, search for Halo
2. Look for the result named Halo: MCC Anti-Cheat Disabled (Mods and Limited Services) and launch it.

====================================================================================================================

这款游戏使用EasyAntiCheat反作弊保护，要使用修改器需禁用EAC，请按照以下步骤运行游戏：

Steam版：
1. 从Steam运行游戏，会弹出两个选项。
2. 选择“玩Halo: MCC Anti-Cheat Disabled (Mods and Limited Services)”

Windows商店版：
1. 打开开始菜单，搜索Halo
2. 从搜索结果中找到Halo: MCC Anti-Cheat Disabled (Mods and Limited Services)，并运行即可。
